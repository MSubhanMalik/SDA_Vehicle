#include "src/services/StaffService.h"
#include "src/ui/SalesmanMenu.h"
#include "src/ui/SurveyorMenu.h"
#include "src/ui/ManagerMenu.h"
#include "src/ui/CustomerPortal.h"
#include "src/ui/MenuHelper.h"
#include <iostream>
#include <fstream>
#include <string>

// Ensure data directory and seed default manager account
void initializeSystem() {
    // Create data directory files if they don't exist
    const char* files[] = {
        "data/customers.dat", "data/vehicles.dat", "data/staff.dat",
        "data/policies.dat",  "data/claims.dat",   "data/inspections.dat",
        "data/workshops.dat", nullptr
    };
    for (int i = 0; files[i] != nullptr; ++i) {
        std::ifstream f(files[i]);
        if (!f.good()) {
            std::ofstream create(files[i]);
        }
    }

    // Seed manager account if no staff exist
    StaffService svc;
    auto all = svc.getAllStaff();
    bool hasManager = false;
    for (const auto& s : all) {
        if (s.role == StaffRole::MANAGER) { hasManager = true; break; }
    }
    if (!hasManager) {
        svc.addStaff("System Manager", "00000-0000000-0", "0300-0000000",
                     "manager@insurance.com", StaffRole::MANAGER,
                     "admin", "admin123");
        std::cout << "  [SYSTEM] Default manager account created.\n";
        std::cout << "  [SYSTEM] Username: admin  Password: admin123\n\n";
    }
}

int main() {
    initializeSystem();

    bool running = true;
    while (running) {
        MenuHelper::printHeader("AUTOMOBILE INSURANCE MANAGEMENT SYSTEM");
        std::cout << "  1. Staff Login\n";
        std::cout << "  2. Customer Portal\n";
        std::cout << "  0. Exit\n";
        int choice = MenuHelper::readInt("  Enter choice: ");

        switch (choice) {
            case 1: {
                std::string uname = MenuHelper::readLine("  Username: ");
                std::string pwd   = MenuHelper::readLine("  Password: ");
                StaffService staffSvc;
                Staff s = staffSvc.authenticate(uname, pwd);
                if (s.id == 0) {
                    std::cout << "  ERROR: Invalid username or password.\n";
                    MenuHelper::pause();
                    break;
                }
                std::cout << "  Welcome, " << s.name << "! (" << roleToString(s.role) << ")\n";
                MenuHelper::pause();
                if (s.role == StaffRole::MANAGER) {
                    ManagerMenu m(s);
                    m.run();
                } else if (s.role == StaffRole::SALESMAN) {
                    SalesmanMenu m(s);
                    m.run();
                } else if (s.role == StaffRole::SURVEYOR) {
                    SurveyorMenu m(s);
                    m.run();
                }
                break;
            }
            case 2: {
                CustomerPortal portal;
                portal.run();
                break;
            }
            case 0:
                std::cout << "  Goodbye.\n";
                running = false;
                break;
            default:
                std::cout << "  Invalid option.\n";
                MenuHelper::pause();
        }
    }
    return 0;
}
