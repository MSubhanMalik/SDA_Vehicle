#pragma once
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <stdexcept>

/**
 * Generic file-based repository.
 * T must provide:
 *   std::string serialize() const
 *   static T deserialize(const std::string&)
 *   int id field
 */
template <typename T>
class FileRepository {
public:
    explicit FileRepository(const std::string& filePath)
        : filePath_(filePath) {}

    // Load all records
    std::vector<T> loadAll() const {
        std::vector<T> records;
        std::ifstream file(filePath_);
        if (!file.is_open()) return records;
        std::string line;
        while (std::getline(file, line)) {
            if (!line.empty()) {
                records.push_back(T::deserialize(line));
            }
        }
        return records;
    }

    // Save one record (append)
    bool save(const T& record) const {
        std::ofstream file(filePath_, std::ios::app);
        if (!file.is_open()) return false;
        file << record.serialize() << "\n";
        return true;
    }

    // Update a record by id (rewrite entire file)
    bool update(const T& updated) const {
        auto records = loadAll();
        bool found = false;
        for (auto& r : records) {
            if (r.id == updated.id) {
                r = updated;
                found = true;
            }
        }
        if (!found) return false;
        return overwrite(records);
    }

    // Delete a record by id
    bool remove(int id) const {
        auto records = loadAll();
        auto it = std::remove_if(records.begin(), records.end(),
                                 [id](const T& r) { return r.id == id; });
        if (it == records.end()) return false;
        records.erase(it, records.end());
        return overwrite(records);
    }

    // Find by id
    T* findById(std::vector<T>& records, int id) const {
        for (auto& r : records) {
            if (r.id == id) return &r;
        }
        return nullptr;
    }

    // Next available ID
    int nextId() const {
        auto records = loadAll();
        int maxId = 0;
        for (const auto& r : records) {
            if (r.id > maxId) maxId = r.id;
        }
        return maxId + 1;
    }

private:
    std::string filePath_;

    bool overwrite(const std::vector<T>& records) const {
        std::ofstream file(filePath_, std::ios::trunc);
        if (!file.is_open()) return false;
        for (const auto& r : records) {
            file << r.serialize() << "\n";
        }
        return true;
    }
};
