#pragma once
#include "FileRepository.h"
#include "../models/Customer.h"
#include "../models/Vehicle.h"
#include "../models/Staff.h"
#include "../models/Policy.h"
#include "../models/Claim.h"
#include "../models/Inspection.h"
#include "../models/Workshop.h"
#include <string>

/**
 * Singleton DataStore providing access to all file repositories.
 * This is the ONLY class that knows about file paths.
 */
class DataStore {
public:
    static DataStore& instance() {
        static DataStore inst;
        return inst;
    }

    FileRepository<Customer>&   customers()   { return customers_; }
    FileRepository<Vehicle>&    vehicles()    { return vehicles_; }
    FileRepository<Staff>&      staff()       { return staff_; }
    FileRepository<Policy>&     policies()    { return policies_; }
    FileRepository<Claim>&      claims()      { return claims_; }
    FileRepository<Inspection>& inspections() { return inspections_; }
    FileRepository<Workshop>&   workshops()   { return workshops_; }

private:
    DataStore()
        : customers_("data/customers.dat"),
          vehicles_("data/vehicles.dat"),
          staff_("data/staff.dat"),
          policies_("data/policies.dat"),
          claims_("data/claims.dat"),
          inspections_("data/inspections.dat"),
          workshops_("data/workshops.dat") {}

    DataStore(const DataStore&) = delete;
    DataStore& operator=(const DataStore&) = delete;

    FileRepository<Customer>   customers_;
    FileRepository<Vehicle>    vehicles_;
    FileRepository<Staff>      staff_;
    FileRepository<Policy>     policies_;
    FileRepository<Claim>      claims_;
    FileRepository<Inspection> inspections_;
    FileRepository<Workshop>   workshops_;
};
