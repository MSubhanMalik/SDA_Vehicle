#pragma once
#include <iostream>
#include <string>
#include <limits>

namespace MenuHelper {

inline void clearInputBuffer() {
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

inline std::string readLine(const std::string& prompt) {
    std::cout << prompt;
    std::string val;
    std::getline(std::cin, val);
    return val;
}

inline int readInt(const std::string& prompt) {
    while (true) {
        std::cout << prompt;
        int val;
        if (std::cin >> val) {
            clearInputBuffer();
            return val;
        }
        std::cout << "  Invalid input. Please enter a number.\n";
        std::cin.clear();
        clearInputBuffer();
    }
}

inline double readDouble(const std::string& prompt) {
    while (true) {
        std::cout << prompt;
        double val;
        if (std::cin >> val) {
            clearInputBuffer();
            return val;
        }
        std::cout << "  Invalid input. Please enter a number.\n";
        std::cin.clear();
        clearInputBuffer();
    }
}

inline void pause() {
    std::cout << "\nPress Enter to continue...";
    std::cin.get();
}

inline void printHeader(const std::string& title) {
    int width = 60;
    std::cout << "\n" << std::string(width, '=') << "\n";
    int pad = (width - static_cast<int>(title.size())) / 2;
    std::cout << std::string(pad > 0 ? pad : 0, ' ') << title << "\n";
    std::cout << std::string(width, '=') << "\n";
}

} // namespace MenuHelper
