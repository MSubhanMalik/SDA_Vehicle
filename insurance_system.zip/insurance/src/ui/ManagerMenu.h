#pragma once
#include "../services/ClaimService.h"
#include "../services/InspectionService.h"
#include "../services/WorkshopService.h"
#include "../services/StaffService.h"
#include "../services/ReportService.h"
#include "../models/Staff.h"
#include "MenuHelper.h"
#include <iostream>
#include <iomanip>

class ManagerMenu {
public:
    explicit ManagerMenu(const Staff& manager)
        : manager_(manager) {}

    void run() {
        bool running = true;
        while (running) {
            MenuHelper::printHeader("MANAGER MENU - " + manager_.name);
            std::cout << "  --- Claims ---\n";
            std::cout << "  1.  View Pending Claims\n";
            std::cout << "  2.  Schedule Inspection for Claim\n";
            std::cout << "  3.  View Inspection Report for Claim\n";
            std::cout << "  4.  Approve Claim\n";
            std::cout << "  5.  Reject Claim\n";
            std::cout << "  6.  Settle Claim (mark as paid)\n";
            std::cout << "  7.  View Customer Claim History\n";
            std::cout << "  --- Workshops ---\n";
            std::cout << "  8.  Register Workshop\n";
            std::cout << "  9.  View All Workshops\n";
            std::cout << "  --- Staff ---\n";
            std::cout << "  10. Add Staff Member\n";
            std::cout << "  11. View All Staff\n";
            std::cout << "  --- Reports ---\n";
            std::cout << "  12. Report: New Customers in Month\n";
            std::cout << "  13. Report: Active Policies\n";
            std::cout << "  14. Report: All Inspection Reports\n";
            std::cout << "  0.  Logout\n";
            int choice = MenuHelper::readInt("  Enter choice: ");

            switch (choice) {
                case 1:  viewPendingClaims();         break;
                case 2:  scheduleInspection();         break;
                case 3:  viewInspectionForClaim();     break;
                case 4:  approveClaim();               break;
                case 5:  rejectClaim();                break;
                case 6:  settleClaim();                break;
                case 7:  viewCustomerClaimHistory();   break;
                case 8:  registerWorkshop();           break;
                case 9:  viewAllWorkshops();           break;
                case 10: addStaff();                   break;
                case 11: viewAllStaff();               break;
                case 12: reportNewCustomers();         break;
                case 13: reportActivePolicies();       break;
                case 14: reportInspections();          break;
                case 0:  running = false;              break;
                default: std::cout << "  Invalid option.\n";
            }
            if (running) MenuHelper::pause();
        }
    }

private:
    Staff             manager_;
    ClaimService      claimSvc_;
    InspectionService inspSvc_;
    WorkshopService   workshopSvc_;
    StaffService      staffSvc_;
    ReportService     reportSvc_;

    void viewPendingClaims() {
        reportSvc_.reportPendingClaims();
    }

    void scheduleInspection() {
        MenuHelper::printHeader("Schedule Inspection");
        int claimId = MenuHelper::readInt("  Claim ID: ");
        Claim c = claimSvc_.findClaim(claimId);
        if (c.id == 0) { std::cout << "  ERROR: Claim not found.\n"; return; }
        if (c.status != ClaimStatus::PENDING) {
            std::cout << "  ERROR: Claim is not in PENDING state.\n"; return;
        }

        // Show surveyors
        auto surveyors = staffSvc_.getSurveyors();
        if (surveyors.empty()) { std::cout << "  ERROR: No surveyors available.\n"; return; }
        std::cout << "  Available Surveyors:\n";
        for (const auto& s : surveyors) {
            std::cout << "    [" << s.id << "] " << s.name << "\n";
        }
        int surveyorId = MenuHelper::readInt("  Surveyor ID: ");
        if (!staffSvc_.staffExistsWithRole(surveyorId, StaffRole::SURVEYOR)) {
            std::cout << "  ERROR: Surveyor not found.\n"; return;
        }

        // Show workshops
        auto workshops = workshopSvc_.getRegisteredWorkshops();
        if (workshops.empty()) { std::cout << "  ERROR: No registered workshops.\n"; return; }
        std::cout << "  Registered Workshops:\n";
        for (const auto& w : workshops) {
            std::cout << "    [" << w.id << "] " << w.name << " - " << w.address << "\n";
        }
        int workshopId = MenuHelper::readInt("  Workshop ID: ");
        if (!workshopSvc_.workshopExists(workshopId)) {
            std::cout << "  ERROR: Workshop not found.\n"; return;
        }

        std::string date = MenuHelper::readLine("  Inspection Date (YYYY-MM-DD): ");

        claimSvc_.assignSurveyor(claimId);
        int insId = inspSvc_.scheduleInspection(claimId, surveyorId, workshopId, date);
        std::cout << "  SUCCESS: Inspection #" << insId << " scheduled.\n";
    }

    void viewInspectionForClaim() {
        int claimId = MenuHelper::readInt("  Claim ID: ");
        auto inspections = inspSvc_.getInspectionsByClaim(claimId);
        MenuHelper::printHeader("Inspections for Claim #" + std::to_string(claimId));
        if (inspections.empty()) { std::cout << "  No inspections found.\n"; return; }
        for (const auto& ins : inspections) {
            std::cout << "  Inspection ID:   " << ins.id             << "\n";
            std::cout << "  Date:            " << ins.inspectionDate  << "\n";
            std::cout << "  Status:          " << inspStatusToStr(ins.status) << "\n";
            std::cout << "  Findings:        " << ins.findings        << "\n";
            std::cout << "  Repair Cost Est: PKR " << std::fixed << std::setprecision(2) << ins.estimatedRepairCost << "\n";
            std::cout << "  Report Date:     " << ins.reportDate      << "\n";
            std::cout << "  " << std::string(50, '-') << "\n";
        }
    }

    void approveClaim() {
        MenuHelper::printHeader("Approve Claim");
        int claimId = MenuHelper::readInt("  Claim ID: ");
        Claim c = claimSvc_.findClaim(claimId);
        if (c.id == 0) { std::cout << "  ERROR: Claim not found.\n"; return; }
        if (c.status != ClaimStatus::UNDER_INSPECTION) {
            std::cout << "  ERROR: Claim must be UNDER_INSPECTION to approve.\n"; return;
        }
        // Show inspection
        auto inspections = inspSvc_.getInspectionsByClaim(claimId);
        bool hasCompleted = false;
        for (const auto& ins : inspections) {
            if (ins.status == InspectionStatus::COMPLETED) {
                std::cout << "  Inspection findings: " << ins.findings << "\n";
                std::cout << "  Estimated repair:    PKR " << std::fixed << std::setprecision(2) << ins.estimatedRepairCost << "\n";
                hasCompleted = true;
            }
        }
        if (!hasCompleted) {
            std::cout << "  WARNING: No completed inspection report yet.\n";
        }
        double amount  = MenuHelper::readDouble("  Approved Amount (PKR): ");
        std::string remarks = MenuHelper::readLine("  Remarks: ");
        if (claimSvc_.approveClaim(claimId, amount, remarks)) {
            std::cout << "  SUCCESS: Claim approved.\n";
        } else {
            std::cout << "  ERROR: Could not approve claim.\n";
        }
    }

    void rejectClaim() {
        MenuHelper::printHeader("Reject Claim");
        int claimId = MenuHelper::readInt("  Claim ID: ");
        std::string remarks = MenuHelper::readLine("  Rejection Reason: ");
        if (claimSvc_.rejectClaim(claimId, remarks)) {
            std::cout << "  SUCCESS: Claim rejected.\n";
        } else {
            std::cout << "  ERROR: Could not reject claim.\n";
        }
    }

    void settleClaim() {
        MenuHelper::printHeader("Settle Claim");
        int claimId = MenuHelper::readInt("  Claim ID: ");
        if (claimSvc_.settleClaim(claimId)) {
            std::cout << "  SUCCESS: Claim marked as SETTLED.\n";
        } else {
            std::cout << "  ERROR: Claim must be APPROVED before settlement.\n";
        }
    }

    void viewCustomerClaimHistory() {
        int custId = MenuHelper::readInt("  Customer ID: ");
        reportSvc_.reportCustomerClaimHistory(custId);
    }

    void registerWorkshop() {
        MenuHelper::printHeader("Register Workshop");
        std::string name  = MenuHelper::readLine("  Workshop Name: ");
        std::string addr  = MenuHelper::readLine("  Address:       ");
        std::string phone = MenuHelper::readLine("  Phone:         ");
        std::string owner = MenuHelper::readLine("  Owner Name:    ");
        int id = workshopSvc_.registerWorkshop(name, addr, phone, owner);
        std::cout << "  SUCCESS: Workshop registered with ID: " << id << "\n";
    }

    void viewAllWorkshops() {
        auto workshops = workshopSvc_.getAllWorkshops();
        MenuHelper::printHeader("All Workshops");
        if (workshops.empty()) { std::cout << "  No workshops.\n"; return; }
        for (const auto& w : workshops) {
            std::cout << "  [" << w.id << "] " << w.name
                      << "  Owner: " << w.ownerName
                      << "  Registered: " << (w.isRegistered ? "YES" : "NO") << "\n";
        }
    }

    void addStaff() {
        MenuHelper::printHeader("Add Staff Member");
        std::string name  = MenuHelper::readLine("  Full Name:  ");
        std::string cnic  = MenuHelper::readLine("  CNIC:       ");
        std::string phone = MenuHelper::readLine("  Phone:      ");
        std::string email = MenuHelper::readLine("  Email:      ");
        std::cout << "  Role: 1=Salesman  2=Surveyor\n";
        int roleChoice = MenuHelper::readInt("  Select: ");
        StaffRole role = (roleChoice == 2) ? StaffRole::SURVEYOR : StaffRole::SALESMAN;
        std::string uname = MenuHelper::readLine("  Username:   ");
        std::string pwd   = MenuHelper::readLine("  Password:   ");
        int id = staffSvc_.addStaff(name, cnic, phone, email, role, uname, pwd);
        if (id == -1) {
            std::cout << "  ERROR: Username already taken.\n";
        } else {
            std::cout << "  SUCCESS: Staff added with ID: " << id << "\n";
        }
    }

    void viewAllStaff() {
        auto staff = staffSvc_.getAllStaff();
        MenuHelper::printHeader("All Staff");
        for (const auto& s : staff) {
            std::cout << "  [" << s.id << "] " << std::left << std::setw(25) << s.name
                      << "  Role: " << roleToString(s.role)
                      << "  User: " << s.username << "\n";
        }
    }

    void reportNewCustomers() {
        std::string ym = MenuHelper::readLine("  Enter Year-Month (YYYY-MM): ");
        reportSvc_.reportNewCustomers(ym);
    }

    void reportActivePolicies() {
        reportSvc_.reportActivePolicies();
    }

    void reportInspections() {
        reportSvc_.reportInspections();
    }
};
