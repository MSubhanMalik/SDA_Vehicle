#pragma once
#include "../services/CustomerService.h"
#include "../services/VehicleService.h"
#include "../services/PolicyService.h"
#include "../services/ClaimService.h"
#include "MenuHelper.h"
#include <iostream>
#include <iomanip>

/**
 * Customer portal - accessed via Customer ID (no password for simplicity,
 * since customers are not staff). Allows viewing policies and filing claims.
 */
class CustomerPortal {
public:
    void run() {
        MenuHelper::printHeader("CUSTOMER PORTAL");
        int custId = MenuHelper::readInt("  Enter your Customer ID: ");
        if (!customerSvc_.customerExists(custId)) {
            std::cout << "  ERROR: Customer not found.\n";
            MenuHelper::pause();
            return;
        }

        bool running = true;
        while (running) {
            MenuHelper::printHeader("CUSTOMER PORTAL");
            std::cout << "  1. View My Policies\n";
            std::cout << "  2. File a Claim\n";
            std::cout << "  3. View My Claims\n";
            std::cout << "  4. View My Vehicles\n";
            std::cout << "  0. Back\n";
            int choice = MenuHelper::readInt("  Enter choice: ");

            switch (choice) {
                case 1: viewPolicies(custId);  break;
                case 2: fileClaim(custId);     break;
                case 3: viewClaims(custId);    break;
                case 4: viewVehicles(custId);  break;
                case 0: running = false;       break;
                default: std::cout << "  Invalid option.\n";
            }
            if (running) MenuHelper::pause();
        }
    }

private:
    CustomerService customerSvc_;
    VehicleService  vehicleSvc_;
    PolicyService   policySvc_;
    ClaimService    claimSvc_;

    void viewPolicies(int custId) {
        auto policies = policySvc_.getPoliciesByCustomer(custId);
        MenuHelper::printHeader("My Policies");
        if (policies.empty()) { std::cout << "  No policies found.\n"; return; }
        for (const auto& p : policies) {
            std::cout << "  [" << p.id << "] " << p.policyNumber
                      << "  Type: " << p.type
                      << "  Premium: PKR " << std::fixed << std::setprecision(2) << p.premium
                      << "  Coverage: PKR " << p.coverageAmount
                      << "  Valid: " << p.startDate << " to " << p.endDate
                      << "  Status: " << policyStatusToStr(p.status) << "\n";
        }
    }

    void fileClaim(int custId) {
        MenuHelper::printHeader("File a Claim");
        viewVehicles(custId);
        int vehId = MenuHelper::readInt("  Vehicle ID to claim for: ");
        if (!vehicleSvc_.vehicleBelongsToCustomer(vehId, custId)) {
            std::cout << "  ERROR: Vehicle not found under your account.\n"; return;
        }
        if (!policySvc_.hasActivePolicy(vehId)) {
            std::cout << "  ERROR: No active policy found for this vehicle.\n"; return;
        }

        // Find the active policy for this vehicle
        auto policies = policySvc_.getPoliciesByCustomer(custId);
        int policyId = 0;
        for (const auto& p : policies) {
            if (p.vehicleId == vehId && p.status == PolicyStatus::ACTIVE) {
                policyId = p.id;
                break;
            }
        }

        std::string accDate = MenuHelper::readLine("  Date of Accident (YYYY-MM-DD): ");
        std::string desc    = MenuHelper::readLine("  Description of Incident:       ");
        double estLoss      = MenuHelper::readDouble("  Estimated Loss Amount (PKR):   ");

        int id = claimSvc_.fileClaim(policyId, custId, vehId, accDate, desc, estLoss);
        std::cout << "  SUCCESS: Claim filed with ID: " << id
                  << ". Our team will contact you shortly.\n";
    }

    void viewClaims(int custId) {
        auto claims = claimSvc_.getClaimsByCustomer(custId);
        MenuHelper::printHeader("My Claims");
        if (claims.empty()) { std::cout << "  No claims found.\n"; return; }
        for (const auto& c : claims) {
            std::cout << "  [" << c.id << "] " << c.claimNumber
                      << "  Accident: " << c.dateOfAccident
                      << "  Est. Loss: PKR " << std::fixed << std::setprecision(2) << c.estimatedLoss
                      << "  Status: " << claimStatusToStr(c.status);
            if (c.status == ClaimStatus::APPROVED || c.status == ClaimStatus::SETTLED) {
                std::cout << "  Approved: PKR " << c.approvedAmount;
            }
            std::cout << "\n";
        }
    }

    void viewVehicles(int custId) {
        auto vehicles = vehicleSvc_.getVehiclesByCustomer(custId);
        MenuHelper::printHeader("My Vehicles");
        if (vehicles.empty()) { std::cout << "  No vehicles registered.\n"; return; }
        for (const auto& v : vehicles) {
            std::cout << "  [" << v.id << "] " << v.registrationNo
                      << "  " << v.year << " " << v.make << " " << v.model << "\n";
        }
    }
};
