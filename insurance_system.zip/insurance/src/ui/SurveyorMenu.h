#pragma once
#include "../services/ClaimService.h"
#include "../services/InspectionService.h"
#include "../services/WorkshopService.h"
#include "../models/Staff.h"
#include "MenuHelper.h"
#include <iostream>
#include <iomanip>

class SurveyorMenu {
public:
    explicit SurveyorMenu(const Staff& surveyor)
        : surveyor_(surveyor) {}

    void run() {
        bool running = true;
        while (running) {
            MenuHelper::printHeader("SURVEYOR MENU - " + surveyor_.name);
            std::cout << "  1. View My Assigned Inspections\n";
            std::cout << "  2. Submit Inspection Report\n";
            std::cout << "  3. View All Registered Workshops\n";
            std::cout << "  4. View Claim Details\n";
            std::cout << "  0. Logout\n";
            int choice = MenuHelper::readInt("  Enter choice: ");

            switch (choice) {
                case 1: viewMyInspections(); break;
                case 2: submitReport(); break;
                case 3: viewWorkshops(); break;
                case 4: viewClaimDetails(); break;
                case 0: running = false; break;
                default: std::cout << "  Invalid option.\n";
            }
            if (running) MenuHelper::pause();
        }
    }

private:
    Staff             surveyor_;
    InspectionService inspSvc_;
    ClaimService      claimSvc_;
    WorkshopService   workshopSvc_;

    void viewMyInspections() {
        auto inspections = inspSvc_.getInspectionsBySurveyor(surveyor_.id);
        MenuHelper::printHeader("My Assigned Inspections");
        if (inspections.empty()) {
            std::cout << "  No inspections assigned.\n"; return;
        }
        std::cout << std::left
                  << std::setw(6)  << "ID"
                  << std::setw(10) << "ClaimID"
                  << std::setw(14) << "Insp. Date"
                  << std::setw(15) << "Status"
                  << std::setw(14) << "Report Date" << "\n";
        std::cout << std::string(60, '-') << "\n";
        for (const auto& ins : inspections) {
            std::cout << std::left
                      << std::setw(6)  << ins.id
                      << std::setw(10) << ins.claimId
                      << std::setw(14) << ins.inspectionDate
                      << std::setw(15) << inspStatusToStr(ins.status)
                      << std::setw(14) << ins.reportDate << "\n";
        }
    }

    void submitReport() {
        MenuHelper::printHeader("Submit Inspection Report");
        int inspId = MenuHelper::readInt("  Inspection ID: ");
        Inspection ins = inspSvc_.findInspection(inspId);
        if (ins.id == 0) {
            std::cout << "  ERROR: Inspection not found.\n"; return;
        }
        if (ins.surveyorId != surveyor_.id) {
            std::cout << "  ERROR: This inspection is not assigned to you.\n"; return;
        }
        if (ins.status == InspectionStatus::COMPLETED) {
            std::cout << "  ERROR: Report already submitted for this inspection.\n"; return;
        }

        std::string findings = MenuHelper::readLine("  Findings:              ");
        double repairCost = MenuHelper::readDouble("  Estimated Repair Cost: ");

        if (inspSvc_.submitReport(inspId, findings, repairCost)) {
            std::cout << "  SUCCESS: Report submitted.\n";
        } else {
            std::cout << "  ERROR: Could not submit report.\n";
        }
    }

    void viewWorkshops() {
        auto workshops = workshopSvc_.getRegisteredWorkshops();
        MenuHelper::printHeader("Registered Workshops");
        if (workshops.empty()) {
            std::cout << "  No registered workshops.\n"; return;
        }
        for (const auto& w : workshops) {
            std::cout << "  [" << w.id << "] " << w.name
                      << " | " << w.address
                      << " | Tel: " << w.phone << "\n";
        }
    }

    void viewClaimDetails() {
        int claimId = MenuHelper::readInt("  Claim ID: ");
        Claim c = claimSvc_.findClaim(claimId);
        if (c.id == 0) {
            std::cout << "  ERROR: Claim not found.\n"; return;
        }
        MenuHelper::printHeader("Claim Details");
        std::cout << "  Claim No:        " << c.claimNumber      << "\n";
        std::cout << "  Accident Date:   " << c.dateOfAccident    << "\n";
        std::cout << "  Description:     " << c.description       << "\n";
        std::cout << "  Est. Loss:       PKR " << std::fixed << std::setprecision(2) << c.estimatedLoss << "\n";
        std::cout << "  Status:          " << claimStatusToStr(c.status) << "\n";
    }
};
