#pragma once
#include "../services/CustomerService.h"
#include "../services/VehicleService.h"
#include "../services/PolicyService.h"
#include "../services/StaffService.h"
#include "../models/Staff.h"
#include "MenuHelper.h"
#include <iostream>
#include <iomanip>

class SalesmanMenu {
public:
    explicit SalesmanMenu(const Staff& salesman)
        : salesman_(salesman) {}

    void run() {
        bool running = true;
        while (running) {
            MenuHelper::printHeader("SALESMAN MENU - " + salesman_.name);
            std::cout << "  1. Register New Customer\n";
            std::cout << "  2. View All Customers\n";
            std::cout << "  3. Add Vehicle for Customer\n";
            std::cout << "  4. View Customer Vehicles\n";
            std::cout << "  5. Issue Insurance Policy\n";
            std::cout << "  6. View Policies by Customer\n";
            std::cout << "  7. View All Active Policies\n";
            std::cout << "  0. Logout\n";
            int choice = MenuHelper::readInt("  Enter choice: ");

            switch (choice) {
                case 1: registerCustomer(); break;
                case 2: viewAllCustomers(); break;
                case 3: addVehicle(); break;
                case 4: viewCustomerVehicles(); break;
                case 5: issuePolicy(); break;
                case 6: viewPoliciesByCustomer(); break;
                case 7: viewActivePolicies(); break;
                case 0: running = false; break;
                default: std::cout << "  Invalid option.\n";
            }
            if (running) MenuHelper::pause();
        }
    }

private:
    Staff           salesman_;
    CustomerService customerSvc_;
    VehicleService  vehicleSvc_;
    PolicyService   policySvc_;

    void registerCustomer() {
        MenuHelper::printHeader("Register New Customer");
        std::string name    = MenuHelper::readLine("  Full Name:    ");
        std::string cnic    = MenuHelper::readLine("  CNIC:         ");
        std::string phone   = MenuHelper::readLine("  Phone:        ");
        std::string address = MenuHelper::readLine("  Address:      ");
        std::string email   = MenuHelper::readLine("  Email:        ");

        int id = customerSvc_.registerCustomer(name, cnic, phone, address, email);
        if (id == -1) {
            std::cout << "  ERROR: A customer with this CNIC already exists.\n";
        } else {
            std::cout << "  SUCCESS: Customer registered with ID: " << id << "\n";
        }
    }

    void viewAllCustomers() {
        auto customers = customerSvc_.getAllCustomers();
        MenuHelper::printHeader("All Customers");
        if (customers.empty()) { std::cout << "  No customers found.\n"; return; }
        std::cout << std::left
                  << std::setw(6)  << "ID"
                  << std::setw(25) << "Name"
                  << std::setw(16) << "CNIC"
                  << std::setw(15) << "Phone"
                  << std::setw(12) << "Joined" << "\n";
        std::cout << std::string(74, '-') << "\n";
        for (const auto& c : customers) {
            std::cout << std::left
                      << std::setw(6)  << c.id
                      << std::setw(25) << c.name
                      << std::setw(16) << c.cnic
                      << std::setw(15) << c.phone
                      << std::setw(12) << c.dateJoined << "\n";
        }
    }

    void addVehicle() {
        MenuHelper::printHeader("Add Vehicle");
        int custId = MenuHelper::readInt("  Customer ID: ");
        if (!customerSvc_.customerExists(custId)) {
            std::cout << "  ERROR: Customer not found.\n"; return;
        }
        std::string reg      = MenuHelper::readLine("  Registration No: ");
        std::string make     = MenuHelper::readLine("  Make:            ");
        std::string model    = MenuHelper::readLine("  Model:           ");
        int year             = MenuHelper::readInt("  Year:            ");
        std::string color    = MenuHelper::readLine("  Color:           ");
        std::string engineNo = MenuHelper::readLine("  Engine No:       ");
        std::string chassis  = MenuHelper::readLine("  Chassis No:      ");

        int id = vehicleSvc_.addVehicle(custId, reg, make, model, year,
                                         color, engineNo, chassis);
        if (id == -1) {
            std::cout << "  ERROR: A vehicle with this registration already exists.\n";
        } else {
            std::cout << "  SUCCESS: Vehicle added with ID: " << id << "\n";
        }
    }

    void viewCustomerVehicles() {
        int custId = MenuHelper::readInt("  Customer ID: ");
        auto vehicles = vehicleSvc_.getVehiclesByCustomer(custId);
        MenuHelper::printHeader("Vehicles for Customer #" + std::to_string(custId));
        if (vehicles.empty()) { std::cout << "  No vehicles found.\n"; return; }
        for (const auto& v : vehicles) {
            std::cout << "  ID: " << v.id << "  Reg: " << v.registrationNo
                      << "  " << v.year << " " << v.make << " " << v.model
                      << " (" << v.color << ")\n";
        }
    }

    void issuePolicy() {
        MenuHelper::printHeader("Issue Insurance Policy");
        int custId = MenuHelper::readInt("  Customer ID:     ");
        if (!customerSvc_.customerExists(custId)) {
            std::cout << "  ERROR: Customer not found.\n"; return;
        }
        int vehId = MenuHelper::readInt("  Vehicle ID:      ");
        if (!vehicleSvc_.vehicleBelongsToCustomer(vehId, custId)) {
            std::cout << "  ERROR: Vehicle not found or doesn't belong to customer.\n"; return;
        }

        std::cout << "  Policy Types:\n";
        std::cout << "    1. Comprehensive\n";
        std::cout << "    2. ThirdParty\n";
        std::cout << "    3. FireAndTheft\n";
        int typeChoice = MenuHelper::readInt("  Select type: ");
        std::string type;
        switch (typeChoice) {
            case 1: type = "Comprehensive"; break;
            case 2: type = "ThirdParty";    break;
            case 3: type = "FireAndTheft";  break;
            default: std::cout << "  Invalid type.\n"; return;
        }

        double premium  = MenuHelper::readDouble("  Annual Premium (PKR): ");
        double coverage = MenuHelper::readDouble("  Coverage Amount (PKR): ");
        std::string start = MenuHelper::readLine("  Start Date (YYYY-MM-DD): ");
        std::string end   = MenuHelper::readLine("  End Date (YYYY-MM-DD):   ");

        int id = policySvc_.issuePolicy(custId, vehId, salesman_.id,
                                         type, premium, coverage, start, end);
        std::cout << "  SUCCESS: Policy issued with ID: " << id << "\n";
    }

    void viewPoliciesByCustomer() {
        int custId = MenuHelper::readInt("  Customer ID: ");
        auto policies = policySvc_.getPoliciesByCustomer(custId);
        MenuHelper::printHeader("Policies for Customer #" + std::to_string(custId));
        if (policies.empty()) { std::cout << "  No policies found.\n"; return; }
        for (const auto& p : policies) {
            std::cout << "  [" << p.id << "] " << p.policyNumber
                      << "  Type: " << p.type
                      << "  Premium: " << std::fixed << std::setprecision(2) << p.premium
                      << "  Status: " << policyStatusToStr(p.status) << "\n";
        }
    }

    void viewActivePolicies() {
        auto policies = policySvc_.getActivePolicies();
        MenuHelper::printHeader("All Active Policies");
        if (policies.empty()) { std::cout << "  No active policies.\n"; return; }
        for (const auto& p : policies) {
            std::cout << "  [" << p.id << "] " << p.policyNumber
                      << "  CustID: " << p.customerId
                      << "  Type: " << p.type
                      << "  Expires: " << p.endDate << "\n";
        }
    }
};
