#pragma once
#include <string>
#include "../include/Utils.h"

struct Workshop {
    int    id;
    std::string name;
    std::string address;
    std::string phone;
    std::string ownerName;
    bool   isRegistered;

    Workshop() : id(0), isRegistered(true) {}
    Workshop(int id, const std::string& name, const std::string& address,
             const std::string& phone, const std::string& ownerName,
             bool isRegistered = true)
        : id(id), name(name), address(address), phone(phone),
          ownerName(ownerName), isRegistered(isRegistered) {}

    std::string serialize() const {
        return std::to_string(id) + "|" +
               Utils::sanitize(name) + "|" +
               Utils::sanitize(address) + "|" +
               Utils::sanitize(phone) + "|" +
               Utils::sanitize(ownerName) + "|" +
               (isRegistered ? "1" : "0");
    }

    static Workshop deserialize(const std::string& line) {
        auto f = Utils::split(line, '|');
        if (f.size() < 6) return Workshop();
        return Workshop(std::stoi(f[0]), f[1], f[2], f[3], f[4], f[5] == "1");
    }
};
