#pragma once
#include <string>
#include "../include/Utils.h"

struct Vehicle {
    int    id;
    int    customerId;
    std::string registrationNo;
    std::string make;
    std::string model;
    int    year;
    std::string color;
    std::string engineNo;
    std::string chassisNo;

    Vehicle() : id(0), customerId(0), year(0) {}
    Vehicle(int id, int customerId, const std::string& reg,
            const std::string& make, const std::string& model,
            int year, const std::string& color,
            const std::string& engineNo, const std::string& chassisNo)
        : id(id), customerId(customerId), registrationNo(reg),
          make(make), model(model), year(year), color(color),
          engineNo(engineNo), chassisNo(chassisNo) {}

    std::string serialize() const {
        return std::to_string(id) + "|" +
               std::to_string(customerId) + "|" +
               Utils::sanitize(registrationNo) + "|" +
               Utils::sanitize(make) + "|" +
               Utils::sanitize(model) + "|" +
               std::to_string(year) + "|" +
               Utils::sanitize(color) + "|" +
               Utils::sanitize(engineNo) + "|" +
               Utils::sanitize(chassisNo);
    }

    static Vehicle deserialize(const std::string& line) {
        auto f = Utils::split(line, '|');
        if (f.size() < 9) return Vehicle();
        return Vehicle(std::stoi(f[0]), std::stoi(f[1]), f[2], f[3],
                       f[4], std::stoi(f[5]), f[6], f[7], f[8]);
    }
};
