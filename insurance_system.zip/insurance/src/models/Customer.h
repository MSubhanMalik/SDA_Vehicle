#pragma once
#include <string>
#include "../include/Utils.h"

struct Customer {
    int    id;
    std::string name;
    std::string cnic;
    std::string phone;
    std::string address;
    std::string email;
    std::string dateJoined; // YYYY-MM-DD

    Customer() : id(0) {}
    Customer(int id, const std::string& name, const std::string& cnic,
             const std::string& phone, const std::string& address,
             const std::string& email, const std::string& dateJoined)
        : id(id), name(name), cnic(cnic), phone(phone),
          address(address), email(email), dateJoined(dateJoined) {}

    std::string serialize() const {
        return std::to_string(id) + "|" +
               Utils::sanitize(name) + "|" +
               Utils::sanitize(cnic) + "|" +
               Utils::sanitize(phone) + "|" +
               Utils::sanitize(address) + "|" +
               Utils::sanitize(email) + "|" +
               dateJoined;
    }

    static Customer deserialize(const std::string& line) {
        auto f = Utils::split(line, '|');
        if (f.size() < 7) return Customer();
        return Customer(std::stoi(f[0]), f[1], f[2], f[3], f[4], f[5], f[6]);
    }
};
