#pragma once
#include <string>
#include "../include/Utils.h"

enum class ClaimStatus {
    PENDING,
    UNDER_INSPECTION,
    APPROVED,
    REJECTED,
    SETTLED
};

inline std::string claimStatusToStr(ClaimStatus s) {
    switch (s) {
        case ClaimStatus::PENDING:          return "PENDING";
        case ClaimStatus::UNDER_INSPECTION: return "UNDER_INSPECTION";
        case ClaimStatus::APPROVED:         return "APPROVED";
        case ClaimStatus::REJECTED:         return "REJECTED";
        case ClaimStatus::SETTLED:          return "SETTLED";
        default:                            return "PENDING";
    }
}

inline ClaimStatus strToClaimStatus(const std::string& s) {
    if (s == "UNDER_INSPECTION") return ClaimStatus::UNDER_INSPECTION;
    if (s == "APPROVED")         return ClaimStatus::APPROVED;
    if (s == "REJECTED")         return ClaimStatus::REJECTED;
    if (s == "SETTLED")          return ClaimStatus::SETTLED;
    return ClaimStatus::PENDING;
}

struct Claim {
    int    id;
    int    policyId;
    int    customerId;
    int    vehicleId;
    std::string claimNumber;
    std::string dateOfAccident;
    std::string description;
    double estimatedLoss;
    double approvedAmount;
    ClaimStatus status;
    std::string dateSubmitted;
    std::string managerRemarks;

    Claim() : id(0), policyId(0), customerId(0), vehicleId(0),
              estimatedLoss(0.0), approvedAmount(0.0),
              status(ClaimStatus::PENDING) {}

    Claim(int id, int pid, int cid, int vid,
          const std::string& cnum, const std::string& accDate,
          const std::string& desc, double estLoss,
          double appAmt, ClaimStatus status,
          const std::string& submitted,
          const std::string& remarks = "")
        : id(id), policyId(pid), customerId(cid), vehicleId(vid),
          claimNumber(cnum), dateOfAccident(accDate), description(desc),
          estimatedLoss(estLoss), approvedAmount(appAmt),
          status(status), dateSubmitted(submitted), managerRemarks(remarks) {}

    std::string serialize() const {
        return std::to_string(id) + "|" +
               std::to_string(policyId) + "|" +
               std::to_string(customerId) + "|" +
               std::to_string(vehicleId) + "|" +
               Utils::sanitize(claimNumber) + "|" +
               dateOfAccident + "|" +
               Utils::sanitize(description) + "|" +
               std::to_string(estimatedLoss) + "|" +
               std::to_string(approvedAmount) + "|" +
               claimStatusToStr(status) + "|" +
               dateSubmitted + "|" +
               Utils::sanitize(managerRemarks);
    }

    static Claim deserialize(const std::string& line) {
        auto f = Utils::split(line, '|');
        if (f.size() < 12) return Claim();
        return Claim(std::stoi(f[0]), std::stoi(f[1]), std::stoi(f[2]),
                     std::stoi(f[3]), f[4], f[5], f[6],
                     std::stod(f[7]), std::stod(f[8]),
                     strToClaimStatus(f[9]), f[10], f[11]);
    }
};
