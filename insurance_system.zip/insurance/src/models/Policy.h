#pragma once
#include <string>
#include "../include/Utils.h"

enum class PolicyStatus { ACTIVE, EXPIRED, CANCELLED };

inline std::string policyStatusToStr(PolicyStatus s) {
    switch (s) {
        case PolicyStatus::ACTIVE:    return "ACTIVE";
        case PolicyStatus::EXPIRED:   return "EXPIRED";
        case PolicyStatus::CANCELLED: return "CANCELLED";
        default:                      return "ACTIVE";
    }
}

inline PolicyStatus strToPolicyStatus(const std::string& s) {
    if (s == "EXPIRED")   return PolicyStatus::EXPIRED;
    if (s == "CANCELLED") return PolicyStatus::CANCELLED;
    return PolicyStatus::ACTIVE;
}

struct Policy {
    int    id;
    int    customerId;
    int    vehicleId;
    int    salesmanId;
    std::string policyNumber;
    std::string type;         // "Comprehensive", "ThirdParty", "FireAndTheft"
    double premium;
    double coverageAmount;
    std::string startDate;
    std::string endDate;
    PolicyStatus status;

    Policy() : id(0), customerId(0), vehicleId(0), salesmanId(0),
               premium(0.0), coverageAmount(0.0), status(PolicyStatus::ACTIVE) {}

    Policy(int id, int cid, int vid, int sid,
           const std::string& pno, const std::string& type,
           double premium, double coverage,
           const std::string& start, const std::string& end,
           PolicyStatus status = PolicyStatus::ACTIVE)
        : id(id), customerId(cid), vehicleId(vid), salesmanId(sid),
          policyNumber(pno), type(type), premium(premium),
          coverageAmount(coverage), startDate(start), endDate(end),
          status(status) {}

    std::string serialize() const {
        return std::to_string(id) + "|" +
               std::to_string(customerId) + "|" +
               std::to_string(vehicleId) + "|" +
               std::to_string(salesmanId) + "|" +
               Utils::sanitize(policyNumber) + "|" +
               Utils::sanitize(type) + "|" +
               std::to_string(premium) + "|" +
               std::to_string(coverageAmount) + "|" +
               startDate + "|" +
               endDate + "|" +
               policyStatusToStr(status);
    }

    static Policy deserialize(const std::string& line) {
        auto f = Utils::split(line, '|');
        if (f.size() < 11) return Policy();
        return Policy(std::stoi(f[0]), std::stoi(f[1]), std::stoi(f[2]),
                      std::stoi(f[3]), f[4], f[5],
                      std::stod(f[6]), std::stod(f[7]),
                      f[8], f[9], strToPolicyStatus(f[10]));
    }
};
