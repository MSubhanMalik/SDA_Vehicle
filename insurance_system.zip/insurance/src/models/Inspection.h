#pragma once
#include <string>
#include "../include/Utils.h"

enum class InspectionStatus { SCHEDULED, COMPLETED };

inline std::string inspStatusToStr(InspectionStatus s) {
    return s == InspectionStatus::COMPLETED ? "COMPLETED" : "SCHEDULED";
}
inline InspectionStatus strToInspStatus(const std::string& s) {
    return s == "COMPLETED" ? InspectionStatus::COMPLETED : InspectionStatus::SCHEDULED;
}

struct Inspection {
    int    id;
    int    claimId;
    int    surveyorId;
    int    workshopId;        // 0 = not yet assigned
    std::string inspectionDate;
    std::string findings;
    double estimatedRepairCost;
    InspectionStatus status;
    std::string reportDate;   // date surveyor submitted report

    Inspection() : id(0), claimId(0), surveyorId(0), workshopId(0),
                   estimatedRepairCost(0.0), status(InspectionStatus::SCHEDULED) {}

    Inspection(int id, int claimId, int surveyorId, int workshopId,
               const std::string& date, const std::string& findings,
               double cost, InspectionStatus status,
               const std::string& reportDate)
        : id(id), claimId(claimId), surveyorId(surveyorId),
          workshopId(workshopId), inspectionDate(date),
          findings(findings), estimatedRepairCost(cost),
          status(status), reportDate(reportDate) {}

    std::string serialize() const {
        return std::to_string(id) + "|" +
               std::to_string(claimId) + "|" +
               std::to_string(surveyorId) + "|" +
               std::to_string(workshopId) + "|" +
               inspectionDate + "|" +
               Utils::sanitize(findings) + "|" +
               std::to_string(estimatedRepairCost) + "|" +
               inspStatusToStr(status) + "|" +
               reportDate;
    }

    static Inspection deserialize(const std::string& line) {
        auto f = Utils::split(line, '|');
        if (f.size() < 9) return Inspection();
        return Inspection(std::stoi(f[0]), std::stoi(f[1]), std::stoi(f[2]),
                          std::stoi(f[3]), f[4], f[5],
                          std::stod(f[6]), strToInspStatus(f[7]), f[8]);
    }
};
