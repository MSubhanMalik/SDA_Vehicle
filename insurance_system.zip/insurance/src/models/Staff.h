#pragma once
#include <string>
#include "../include/Utils.h"

// StaffRole enum
enum class StaffRole { SALESMAN, SURVEYOR, MANAGER };

inline std::string roleToString(StaffRole r) {
    switch (r) {
        case StaffRole::SALESMAN:  return "SALESMAN";
        case StaffRole::SURVEYOR:  return "SURVEYOR";
        case StaffRole::MANAGER:   return "MANAGER";
        default:                   return "UNKNOWN";
    }
}

inline StaffRole stringToRole(const std::string& s) {
    if (s == "SALESMAN")  return StaffRole::SALESMAN;
    if (s == "SURVEYOR")  return StaffRole::SURVEYOR;
    return StaffRole::MANAGER;
}

struct Staff {
    int    id;
    std::string name;
    std::string cnic;
    std::string phone;
    std::string email;
    StaffRole   role;
    std::string username;
    std::string password;  // plain text (acceptable for academic project)

    Staff() : id(0), role(StaffRole::SALESMAN) {}
    Staff(int id, const std::string& name, const std::string& cnic,
          const std::string& phone, const std::string& email,
          StaffRole role, const std::string& username,
          const std::string& password)
        : id(id), name(name), cnic(cnic), phone(phone), email(email),
          role(role), username(username), password(password) {}

    std::string serialize() const {
        return std::to_string(id) + "|" +
               Utils::sanitize(name) + "|" +
               Utils::sanitize(cnic) + "|" +
               Utils::sanitize(phone) + "|" +
               Utils::sanitize(email) + "|" +
               roleToString(role) + "|" +
               Utils::sanitize(username) + "|" +
               Utils::sanitize(password);
    }

    static Staff deserialize(const std::string& line) {
        auto f = Utils::split(line, '|');
        if (f.size() < 8) return Staff();
        return Staff(std::stoi(f[0]), f[1], f[2], f[3], f[4],
                     stringToRole(f[5]), f[6], f[7]);
    }
};
