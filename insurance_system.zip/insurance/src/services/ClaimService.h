#pragma once
#include "../repositories/DataStore.h"
#include "../models/Claim.h"
#include "../include/Utils.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

class ClaimService {
public:
    int fileClaim(int policyId, int customerId, int vehicleId,
                  const std::string& accidentDate,
                  const std::string& description,
                  double estimatedLoss) {
        int id = DataStore::instance().claims().nextId();
        std::string cnum = generateClaimNumber(id);
        Claim c(id, policyId, customerId, vehicleId, cnum,
                accidentDate, description, estimatedLoss,
                0.0, ClaimStatus::PENDING, Utils::currentDate());
        DataStore::instance().claims().save(c);
        return id;
    }

    bool assignSurveyor(int claimId) {
        // Marks claim as UNDER_INSPECTION
        auto all = DataStore::instance().claims().loadAll();
        for (auto& c : all) {
            if (c.id == claimId) {
                if (c.status != ClaimStatus::PENDING) return false;
                c.status = ClaimStatus::UNDER_INSPECTION;
                return DataStore::instance().claims().update(c);
            }
        }
        return false;
    }

    bool approveClaim(int claimId, double approvedAmount,
                      const std::string& remarks) {
        auto all = DataStore::instance().claims().loadAll();
        for (auto& c : all) {
            if (c.id == claimId) {
                c.status         = ClaimStatus::APPROVED;
                c.approvedAmount = approvedAmount;
                c.managerRemarks = remarks;
                return DataStore::instance().claims().update(c);
            }
        }
        return false;
    }

    bool rejectClaim(int claimId, const std::string& remarks) {
        auto all = DataStore::instance().claims().loadAll();
        for (auto& c : all) {
            if (c.id == claimId) {
                c.status         = ClaimStatus::REJECTED;
                c.managerRemarks = remarks;
                return DataStore::instance().claims().update(c);
            }
        }
        return false;
    }

    bool settleClaim(int claimId) {
        auto all = DataStore::instance().claims().loadAll();
        for (auto& c : all) {
            if (c.id == claimId) {
                if (c.status != ClaimStatus::APPROVED) return false;
                c.status = ClaimStatus::SETTLED;
                return DataStore::instance().claims().update(c);
            }
        }
        return false;
    }

    std::vector<Claim> getPendingClaims() {
        auto all = DataStore::instance().claims().loadAll();
        std::vector<Claim> result;
        for (const auto& c : all) {
            if (c.status == ClaimStatus::PENDING ||
                c.status == ClaimStatus::UNDER_INSPECTION) {
                result.push_back(c);
            }
        }
        return result;
    }

    std::vector<Claim> getClaimsByCustomer(int customerId) {
        auto all = DataStore::instance().claims().loadAll();
        std::vector<Claim> result;
        for (const auto& c : all) {
            if (c.customerId == customerId) result.push_back(c);
        }
        return result;
    }

    std::vector<Claim> getAllClaims() {
        return DataStore::instance().claims().loadAll();
    }

    Claim findClaim(int id) {
        auto all = DataStore::instance().claims().loadAll();
        for (const auto& c : all) {
            if (c.id == id) return c;
        }
        return Claim();
    }

    bool claimExists(int id) {
        auto all = DataStore::instance().claims().loadAll();
        for (const auto& c : all) {
            if (c.id == id) return true;
        }
        return false;
    }

private:
    std::string generateClaimNumber(int id) {
        std::ostringstream oss;
        oss << "CLM-" << std::setw(6) << std::setfill('0') << id;
        return oss.str();
    }
};
