#pragma once
#include "../repositories/DataStore.h"
#include "../models/Inspection.h"
#include "../include/Utils.h"
#include <vector>
#include <string>

class InspectionService {
public:
    int scheduleInspection(int claimId, int surveyorId,
                           int workshopId, const std::string& date) {
        int id = DataStore::instance().inspections().nextId();
        Inspection ins(id, claimId, surveyorId, workshopId,
                       date, "", 0.0,
                       InspectionStatus::SCHEDULED, "");
        DataStore::instance().inspections().save(ins);
        return id;
    }

    bool submitReport(int inspectionId, const std::string& findings,
                      double repairCost) {
        auto all = DataStore::instance().inspections().loadAll();
        for (auto& ins : all) {
            if (ins.id == inspectionId) {
                ins.findings           = findings;
                ins.estimatedRepairCost = repairCost;
                ins.status             = InspectionStatus::COMPLETED;
                ins.reportDate         = Utils::currentDate();
                return DataStore::instance().inspections().update(ins);
            }
        }
        return false;
    }

    std::vector<Inspection> getInspectionsByClaim(int claimId) {
        auto all = DataStore::instance().inspections().loadAll();
        std::vector<Inspection> result;
        for (const auto& ins : all) {
            if (ins.claimId == claimId) result.push_back(ins);
        }
        return result;
    }

    std::vector<Inspection> getInspectionsBySurveyor(int surveyorId) {
        auto all = DataStore::instance().inspections().loadAll();
        std::vector<Inspection> result;
        for (const auto& ins : all) {
            if (ins.surveyorId == surveyorId) result.push_back(ins);
        }
        return result;
    }

    std::vector<Inspection> getAllInspections() {
        return DataStore::instance().inspections().loadAll();
    }

    Inspection findInspection(int id) {
        auto all = DataStore::instance().inspections().loadAll();
        for (const auto& ins : all) {
            if (ins.id == id) return ins;
        }
        return Inspection();
    }
};
