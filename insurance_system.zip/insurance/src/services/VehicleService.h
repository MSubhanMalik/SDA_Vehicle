#pragma once
#include "../repositories/DataStore.h"
#include "../models/Vehicle.h"
#include <vector>
#include <string>

class VehicleService {
public:
    int addVehicle(int customerId, const std::string& reg,
                   const std::string& make, const std::string& model,
                   int year, const std::string& color,
                   const std::string& engineNo, const std::string& chassisNo) {
        // Duplicate registration check
        auto all = DataStore::instance().vehicles().loadAll();
        for (const auto& v : all) {
            if (v.registrationNo == reg) return -1;
        }
        int id = DataStore::instance().vehicles().nextId();
        Vehicle v(id, customerId, reg, make, model, year, color, engineNo, chassisNo);
        DataStore::instance().vehicles().save(v);
        return id;
    }

    std::vector<Vehicle> getVehiclesByCustomer(int customerId) {
        auto all = DataStore::instance().vehicles().loadAll();
        std::vector<Vehicle> result;
        for (const auto& v : all) {
            if (v.customerId == customerId) result.push_back(v);
        }
        return result;
    }

    std::vector<Vehicle> getAllVehicles() {
        return DataStore::instance().vehicles().loadAll();
    }

    bool vehicleExists(int id) {
        auto all = DataStore::instance().vehicles().loadAll();
        for (const auto& v : all) {
            if (v.id == id) return true;
        }
        return false;
    }

    bool vehicleBelongsToCustomer(int vehicleId, int customerId) {
        auto all = DataStore::instance().vehicles().loadAll();
        for (const auto& v : all) {
            if (v.id == vehicleId && v.customerId == customerId) return true;
        }
        return false;
    }
};
