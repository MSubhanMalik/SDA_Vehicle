#pragma once
#include "CustomerService.h"
#include "PolicyService.h"
#include "ClaimService.h"
#include "InspectionService.h"
#include "StaffService.h"
#include "WorkshopService.h"
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>

/**
 * ReportService - generates textual reports for the manager.
 * Composes other services (has-a relationship).
 */
class ReportService {
public:
    ReportService()
        : customerSvc_(), policySvc_(), claimSvc_(),
          inspSvc_(), staffSvc_(), workshopSvc_() {}

    void reportNewCustomers(const std::string& yearMonth) {
        auto customers = customerSvc_.newCustomersInMonth(yearMonth);
        std::cout << "\n=== New Customers in " << yearMonth
                  << " (" << customers.size() << " total) ===\n";
        printLine();
        std::cout << std::left
                  << std::setw(6)  << "ID"
                  << std::setw(25) << "Name"
                  << std::setw(16) << "CNIC"
                  << std::setw(15) << "Phone"
                  << std::setw(12) << "Date Joined" << "\n";
        printLine();
        for (const auto& c : customers) {
            std::cout << std::left
                      << std::setw(6)  << c.id
                      << std::setw(25) << c.name
                      << std::setw(16) << c.cnic
                      << std::setw(15) << c.phone
                      << std::setw(12) << c.dateJoined << "\n";
        }
        printLine();
    }

    void reportPendingClaims() {
        auto claims = claimSvc_.getPendingClaims();
        std::cout << "\n=== Pending / Under-Inspection Claims ("
                  << claims.size() << " total) ===\n";
        printLine();
        std::cout << std::left
                  << std::setw(8)  << "ID"
                  << std::setw(15) << "Claim No."
                  << std::setw(12) << "Date Filed"
                  << std::setw(15) << "Est. Loss"
                  << std::setw(20) << "Status" << "\n";
        printLine();
        for (const auto& c : claims) {
            std::cout << std::left
                      << std::setw(8)  << c.id
                      << std::setw(15) << c.claimNumber
                      << std::setw(12) << c.dateSubmitted
                      << std::setw(15) << std::fixed << std::setprecision(2) << c.estimatedLoss
                      << std::setw(20) << claimStatusToStr(c.status) << "\n";
        }
        printLine();
    }

    void reportInspections() {
        auto inspections = inspSvc_.getAllInspections();
        std::cout << "\n=== Inspection Reports (" << inspections.size() << " total) ===\n";
        printLine();
        std::cout << std::left
                  << std::setw(6)  << "ID"
                  << std::setw(10) << "ClaimID"
                  << std::setw(12) << "Insp. Date"
                  << std::setw(15) << "Repair Cost"
                  << std::setw(15) << "Status"
                  << std::setw(12) << "Report Date" << "\n";
        printLine();
        for (const auto& ins : inspections) {
            std::cout << std::left
                      << std::setw(6)  << ins.id
                      << std::setw(10) << ins.claimId
                      << std::setw(12) << ins.inspectionDate
                      << std::setw(15) << std::fixed << std::setprecision(2) << ins.estimatedRepairCost
                      << std::setw(15) << inspStatusToStr(ins.status)
                      << std::setw(12) << ins.reportDate << "\n";
        }
        printLine();
    }

    void reportCustomerClaimHistory(int customerId) {
        auto claims = claimSvc_.getClaimsByCustomer(customerId);
        std::cout << "\n=== Claim History for Customer #" << customerId
                  << " (" << claims.size() << " claims) ===\n";
        printLine();
        std::cout << std::left
                  << std::setw(8)  << "ID"
                  << std::setw(15) << "Claim No."
                  << std::setw(12) << "Accident"
                  << std::setw(15) << "Est. Loss"
                  << std::setw(15) << "Approved"
                  << std::setw(20) << "Status" << "\n";
        printLine();
        for (const auto& c : claims) {
            std::cout << std::left
                      << std::setw(8)  << c.id
                      << std::setw(15) << c.claimNumber
                      << std::setw(12) << c.dateOfAccident
                      << std::setw(15) << std::fixed << std::setprecision(2) << c.estimatedLoss
                      << std::setw(15) << c.approvedAmount
                      << std::setw(20) << claimStatusToStr(c.status) << "\n";
        }
        printLine();
    }

    void reportActivePolicies() {
        auto policies = policySvc_.getActivePolicies();
        std::cout << "\n=== Active Policies (" << policies.size() << " total) ===\n";
        printLine();
        std::cout << std::left
                  << std::setw(8)  << "ID"
                  << std::setw(15) << "Policy No."
                  << std::setw(10) << "CustID"
                  << std::setw(20) << "Type"
                  << std::setw(12) << "Premium"
                  << std::setw(12) << "Start"
                  << std::setw(12) << "End" << "\n";
        printLine();
        for (const auto& p : policies) {
            std::cout << std::left
                      << std::setw(8)  << p.id
                      << std::setw(15) << p.policyNumber
                      << std::setw(10) << p.customerId
                      << std::setw(20) << p.type
                      << std::setw(12) << std::fixed << std::setprecision(2) << p.premium
                      << std::setw(12) << p.startDate
                      << std::setw(12) << p.endDate << "\n";
        }
        printLine();
    }

private:
    CustomerService   customerSvc_;
    PolicyService     policySvc_;
    ClaimService      claimSvc_;
    InspectionService inspSvc_;
    StaffService      staffSvc_;
    WorkshopService   workshopSvc_;

    void printLine() const {
        std::cout << std::string(85, '-') << "\n";
    }
};
