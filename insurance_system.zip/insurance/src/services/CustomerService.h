#pragma once
#include "../repositories/DataStore.h"
#include "../models/Customer.h"
#include "../include/Utils.h"
#include <vector>
#include <string>
#include <algorithm>

class CustomerService {
public:
    // Register a new customer; returns the assigned ID, or -1 on failure
    int registerCustomer(const std::string& name, const std::string& cnic,
                         const std::string& phone, const std::string& address,
                         const std::string& email) {
        // Duplicate CNIC check
        auto existing = DataStore::instance().customers().loadAll();
        for (const auto& c : existing) {
            if (c.cnic == cnic) return -1;
        }
        int id = DataStore::instance().customers().nextId();
        Customer c(id, name, cnic, phone, address, email, Utils::currentDate());
        DataStore::instance().customers().save(c);
        return id;
    }

    bool updateCustomer(int id, const std::string& phone,
                        const std::string& address, const std::string& email) {
        auto all = DataStore::instance().customers().loadAll();
        auto* c = DataStore::instance().customers().findById(all, id);
        if (!c) return false;
        c->phone   = phone;
        c->address = address;
        c->email   = email;
        return DataStore::instance().customers().update(*c);
    }

    std::vector<Customer> getAllCustomers() {
        return DataStore::instance().customers().loadAll();
    }

    Customer* findById(std::vector<Customer>& all, int id) {
        return DataStore::instance().customers().findById(all, id);
    }

    // New customers in a given month (YYYY-MM)
    std::vector<Customer> newCustomersInMonth(const std::string& yearMonth) {
        auto all = DataStore::instance().customers().loadAll();
        std::vector<Customer> result;
        for (const auto& c : all) {
            if (c.dateJoined.substr(0, 7) == yearMonth) {
                result.push_back(c);
            }
        }
        return result;
    }

    bool customerExists(int id) {
        auto all = DataStore::instance().customers().loadAll();
        for (const auto& c : all) {
            if (c.id == id) return true;
        }
        return false;
    }
};
