#pragma once
#include "../repositories/DataStore.h"
#include "../models/Workshop.h"
#include <vector>
#include <string>

class WorkshopService {
public:
    int registerWorkshop(const std::string& name, const std::string& address,
                         const std::string& phone, const std::string& ownerName) {
        int id = DataStore::instance().workshops().nextId();
        Workshop w(id, name, address, phone, ownerName, true);
        DataStore::instance().workshops().save(w);
        return id;
    }

    bool deregisterWorkshop(int id) {
        auto all = DataStore::instance().workshops().loadAll();
        for (auto& w : all) {
            if (w.id == id) {
                w.isRegistered = false;
                return DataStore::instance().workshops().update(w);
            }
        }
        return false;
    }

    std::vector<Workshop> getRegisteredWorkshops() {
        auto all = DataStore::instance().workshops().loadAll();
        std::vector<Workshop> result;
        for (const auto& w : all) {
            if (w.isRegistered) result.push_back(w);
        }
        return result;
    }

    std::vector<Workshop> getAllWorkshops() {
        return DataStore::instance().workshops().loadAll();
    }

    bool workshopExists(int id) {
        auto all = DataStore::instance().workshops().loadAll();
        for (const auto& w : all) {
            if (w.id == id && w.isRegistered) return true;
        }
        return false;
    }

    Workshop findById(int id) {
        auto all = DataStore::instance().workshops().loadAll();
        for (const auto& w : all) {
            if (w.id == id) return w;
        }
        return Workshop();
    }
};
