#pragma once
#include "../repositories/DataStore.h"
#include "../models/Policy.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

class PolicyService {
public:
    int issuePolicy(int customerId, int vehicleId, int salesmanId,
                    const std::string& type, double premium,
                    double coverage, const std::string& startDate,
                    const std::string& endDate) {
        int id = DataStore::instance().policies().nextId();
        std::string pno = generatePolicyNumber(id);
        Policy p(id, customerId, vehicleId, salesmanId, pno, type,
                 premium, coverage, startDate, endDate);
        DataStore::instance().policies().save(p);
        return id;
    }

    bool cancelPolicy(int policyId) {
        auto all = DataStore::instance().policies().loadAll();
        for (auto& p : all) {
            if (p.id == policyId) {
                p.status = PolicyStatus::CANCELLED;
                return DataStore::instance().policies().update(p);
            }
        }
        return false;
    }

    std::vector<Policy> getPoliciesByCustomer(int customerId) {
        auto all = DataStore::instance().policies().loadAll();
        std::vector<Policy> result;
        for (const auto& p : all) {
            if (p.customerId == customerId) result.push_back(p);
        }
        return result;
    }

    std::vector<Policy> getActivePolicies() {
        auto all = DataStore::instance().policies().loadAll();
        std::vector<Policy> result;
        for (const auto& p : all) {
            if (p.status == PolicyStatus::ACTIVE) result.push_back(p);
        }
        return result;
    }

    std::vector<Policy> getAllPolicies() {
        return DataStore::instance().policies().loadAll();
    }

    bool policyExists(int id) {
        auto all = DataStore::instance().policies().loadAll();
        for (const auto& p : all) {
            if (p.id == id) return true;
        }
        return false;
    }

    Policy findPolicy(int id) {
        auto all = DataStore::instance().policies().loadAll();
        for (const auto& p : all) {
            if (p.id == id) return p;
        }
        return Policy();
    }

    bool hasActivePolicy(int vehicleId) {
        auto all = DataStore::instance().policies().loadAll();
        for (const auto& p : all) {
            if (p.vehicleId == vehicleId && p.status == PolicyStatus::ACTIVE)
                return true;
        }
        return false;
    }

private:
    std::string generatePolicyNumber(int id) {
        std::ostringstream oss;
        oss << "POL-" << std::setw(6) << std::setfill('0') << id;
        return oss.str();
    }
};
