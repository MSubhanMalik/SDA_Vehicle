#pragma once
#include "../repositories/DataStore.h"
#include "../models/Staff.h"
#include <vector>
#include <string>

class StaffService {
public:
    int addStaff(const std::string& name, const std::string& cnic,
                 const std::string& phone, const std::string& email,
                 StaffRole role, const std::string& username,
                 const std::string& password) {
        // Duplicate username check
        auto all = DataStore::instance().staff().loadAll();
        for (const auto& s : all) {
            if (s.username == username) return -1;
        }
        int id = DataStore::instance().staff().nextId();
        Staff s(id, name, cnic, phone, email, role, username, password);
        DataStore::instance().staff().save(s);
        return id;
    }

    // Returns nullptr-equivalent (id=0) if not found or wrong password
    Staff authenticate(const std::string& username, const std::string& password) {
        auto all = DataStore::instance().staff().loadAll();
        for (const auto& s : all) {
            if (s.username == username && s.password == password) return s;
        }
        return Staff();
    }

    std::vector<Staff> getSurveyors() {
        auto all = DataStore::instance().staff().loadAll();
        std::vector<Staff> result;
        for (const auto& s : all) {
            if (s.role == StaffRole::SURVEYOR) result.push_back(s);
        }
        return result;
    }

    std::vector<Staff> getSalesmen() {
        auto all = DataStore::instance().staff().loadAll();
        std::vector<Staff> result;
        for (const auto& s : all) {
            if (s.role == StaffRole::SALESMAN) result.push_back(s);
        }
        return result;
    }

    std::vector<Staff> getAllStaff() {
        return DataStore::instance().staff().loadAll();
    }

    bool staffExists(int id) {
        auto all = DataStore::instance().staff().loadAll();
        for (const auto& s : all) {
            if (s.id == id) return true;
        }
        return false;
    }

    bool staffExistsWithRole(int id, StaffRole role) {
        auto all = DataStore::instance().staff().loadAll();
        for (const auto& s : all) {
            if (s.id == id && s.role == role) return true;
        }
        return false;
    }

    Staff findById(int id) {
        auto all = DataStore::instance().staff().loadAll();
        for (const auto& s : all) {
            if (s.id == id) return s;
        }
        return Staff();
    }
};
