#pragma once
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <ctime>
#include <iomanip>

namespace Utils {

inline std::string currentDate() {
    std::time_t t = std::time(nullptr);
    std::tm* tm = std::localtime(&t);
    std::ostringstream oss;
    oss << std::put_time(tm, "%Y-%m-%d");
    return oss.str();
}

inline std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> tokens;
    std::istringstream ss(s);
    std::string token;
    while (std::getline(ss, token, delim)) {
        tokens.push_back(token);
    }
    return tokens;
}

inline std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    size_t end   = s.find_last_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    return s.substr(start, end - start + 1);
}

// Replace pipe characters to avoid CSV corruption
inline std::string sanitize(const std::string& s) {
    std::string out = s;
    std::replace(out.begin(), out.end(), '|', '-');
    return out;
}

inline int generateId(const std::string& prefix, int counter) {
    (void)prefix;
    return counter;
}

} // namespace Utils
